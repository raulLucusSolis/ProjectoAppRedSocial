<?php
session_start();
require 'php/db.php';

// Verificar que el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Obtener el ID del usuario cuyo perfil se está viendo
$id_usuario = isset($_GET['id']) ? $_GET['id'] : $_SESSION['user_id'];

// Obtener los datos del usuario
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$id_usuario]);
$user = $stmt->fetch();

if (!$user) {
    die("Usuario no encontrado.");
}

// Obtener las publicaciones del usuario
$stmt = $pdo->prepare("SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$id_usuario]);
$posts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Perfil de <?php echo htmlspecialchars($user['nombre']); ?></title>
</head>
<body>
    <h1>Perfil de <?php echo htmlspecialchars($user['nombre']); ?> <?php echo htmlspecialchars($user['apellidos']); ?></h1>
    
    <a href="usuarios.php">Ver todos los usuarios</a> | <a href="dashboard.php">Volver al Dashboard</a>

    <h2>Mis Datos:</h2>
    <p><strong>Nombre:</strong> <?php echo htmlspecialchars($user['nombre']); ?></p>
    <p><strong>Apellidos:</strong> <?php echo htmlspecialchars($user['apellidos']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>

    <h2>Imagen de Perfil:</h2>
    <?php if ($user['avatar']): ?>
        <img src="../<?php echo htmlspecialchars($user['avatar']); ?>" alt="Avatar" width="150"><br>
    <?php else: ?>
        <p>No ha subido una imagen de perfil.</p>
    <?php endif; ?>

    <h2>Publicaciones de <?php echo htmlspecialchars($user['nombre']); ?>:</h2>
    <?php foreach ($posts as $post): ?>
        <div>
            <p><?php echo htmlspecialchars($post['content']); ?></p>
            <?php if ($post['image']): ?>
                <img src="../<?php echo htmlspecialchars($post['image']); ?>" alt="Imagen" width="100"><br>
            <?php endif; ?>
            <small>Publicado el <?php echo $post['created_at']; ?></small>
        </div>
    <?php endforeach; ?>
</body>
</html>
