<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Log In</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Log In</h1>
    <form action="php/login_handler.php" method="post">
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>

        <button type="submit">Log In</button>
    </form>

    <p><a href="index.php">Back to Home Page</a></p>
</body>
</html>
