<?php
session_start();
require 'php/db.php';

// Verificar que el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Consultar todos los usuarios
$stmt = $pdo->query("SELECT * FROM usuarios");
$usuarios = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Usuarios</title>
</head>
<body>
    <h1>Usuarios Registrados</h1>
    <a href="dashboard.php">Volver al Dashboard</a>

    <h2>Lista de Usuarios:</h2>
    <ul>
        <?php foreach ($usuarios as $usuario): ?>
            <li>
                <strong><?php echo htmlspecialchars($usuario['nombre']); ?> <?php echo htmlspecialchars($usuario['apellidos']); ?></strong><br>
                <a href="perfil.php?id=<?php echo $usuario['id']; ?>">Ver perfil</a>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
