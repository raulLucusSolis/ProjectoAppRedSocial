<?php
require 'db.php';
require 'functions.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recoger los datos del formulario
    $nombre = recue('nombre');
    $apellidos = recue('apellidos');
    $email = recue('email');
    $password = recue('password');
    $avatar = null;

    // Inicializar validaciones
    $nombreok = $apellidosok = $emailok = $passwordok = false;

    // Validar Nombre
    if ($nombre == "") {
        echo "The name cannot be empty.<br>";
    } elseif (strlen($nombre) < 2 || strlen($nombre) > 50) {
        echo "The name must be between 2 and 50 characters.<br>";
    } elseif (preg_match('/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/', $nombre)) {
        echo "The name cannot contain special characters or numbers.<br>";
    } else {
        $nombreok = true;
    }

    // Validar Apellidos
    if ($apellidos == "") {
        echo "The last name cannot be empty.<br>";
    } elseif (strlen($apellidos) < 2 || strlen($apellidos) > 50) {
        echo "The last name must be between 2 and 50 characters.<br>";
    } elseif (preg_match('/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/', $apellidos)) {
        echo "The last name cannot contain special characters or numbers.<br>";
    } else {
        $apellidosok = true;
    }

    // Validar Email
    if ($email == "") {
        echo "The email cannot be empty.<br>";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "The email format is invalid.<br>";
    } else {
        // Verificar si el email ya existe
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            echo "The email is already registered.<br>";
        } else {
            $emailok = true;
        }
    }

// Validar Contraseña
$passwordok = false;

if ($password == "") {
    echo "The password cannot be empty.<br>";
} elseif (strlen($password) < 13) {
    echo "The password must be at least 13 characters long.<br>";
} elseif (!preg_match('/[A-Z]/', $password)) {
    echo "The password must include at least one uppercase letter.<br>";
} elseif (!preg_match('/[a-z]/', $password)) {
    echo "The password must include at least one lowercase letter.<br>";
} elseif (!preg_match('/[\W_]/', $password)) { // Special character
    echo "The password must include at least one special character.<br>";
} elseif (!preg_match('/[0-9]/', $password)) {
    echo "The password must include at least one number.<br>";
} else {
    $passwordok = true;
}


    // Validar Avatar (opcional)
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/project/uploads/';
        $tmp_name = $_FILES['avatar']['tmp_name'];
        $name = basename($_FILES['avatar']['name']);
        if (move_uploaded_file($tmp_name, $uploadDir . $name)) {
            $avatar = "uploads/$name";
        } else {
            echo "Error uploading the avatar.<br>";
        }
    }

    // Comprobar si todas las validaciones pasaron
    if ($nombreok && $apellidosok && $emailok && $passwordok) {
        // Insertar el usuario en la base de datos
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, apellidos, email, password, avatar) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nombre, $apellidos, $email, $hashed_password, $avatar]);

        echo "Registration successful. You can now log in.";
        header("Location: ../login.php");
        exit;
    } else {
        echo "There were errors in the registration. Please correct the issues and try again.<br>";
    }
}
?>
