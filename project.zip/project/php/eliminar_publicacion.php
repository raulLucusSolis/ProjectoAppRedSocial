<?php
session_start();
require 'db.php';

// Verificar que el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); // Redirigir al login si no está autenticado
    exit;
}

// Verificar que se recibió el ID de la publicación
if (!isset($_GET['id'])) {
    die("Error: ID de publicación no proporcionado.");
}

$post_id = $_GET['id'];

// Obtener los datos actuales de la publicación
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$post_id, $_SESSION['user_id']]);
$post = $stmt->fetch();

if (!$post) {
    die("Error: Publicación no encontrada o no tienes permiso para eliminarla.");
}

// Eliminar la publicación de la base de datos
$stmt = $pdo->prepare("DELETE FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$post_id, $_SESSION['user_id']]);

// Eliminar la imagen asociada (si existe)
if ($post['image']) {
    $imagePath = $_SERVER['DOCUMENT_ROOT'] . '/project/' . $post['image'];
    if (file_exists($imagePath)) {
        unlink($imagePath); // Elimina el archivo físico
    }
}

// Redirigir al Dashboard
header("Location: ../dashboard.php");
exit;
?>
