<?php
session_start();
require 'db.php';

// Recoger los datos del formulario
$email = $_POST['email'];
$password = $_POST['password'];

// Consultar si el usuario existe
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

// Verificar si el usuario existe y la contraseña es correcta
if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    header("Location: ../dashboard.php");  // Redirigir al dashboard
} else {
    echo "Credenciales incorrectas.";
}
?>
