<?php
session_start();
require 'db.php';

// Verificar que el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Obtener los datos actuales del usuario
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    die("Error: Usuario no encontrado.");
}

// Procesar la eliminación
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['confirmar']) && $_POST['confirmar'] == 'on') {
        // Eliminar las publicaciones del usuario
        $stmt = $pdo->prepare("DELETE FROM posts WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);

        // Eliminar la imagen del avatar si existe
        if ($user['avatar']) {
            $avatarPath = $_SERVER['DOCUMENT_ROOT'] . '/project/' . $user['avatar'];
            if (file_exists($avatarPath)) {
                unlink($avatarPath); // Eliminar el archivo de avatar
            }
        }

        // Eliminar el usuario de la base de datos
        $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);

        // Cerrar la sesión y redirigir a la página principal
        session_destroy();
        header("Location: ../index.php");
        exit;
    } else {
        $error = "Debe marcar la casilla para confirmar la eliminación.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Delete Account</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .container {
            max-width: 500px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .container h1 {
            font-size: 24px;
            text-align: center;
            margin-bottom: 20px;
        }

        .warning {
            color: #d9534f;
            font-weight: bold;
            margin-bottom: 10px;
        }

        ul {
            list-style-type: none;
            padding: 0;
            margin-bottom: 20px;
        }

        ul li {
            margin-bottom: 10px;
        }

        .avatar img {
            display: block;
            margin: 10px auto;
            border-radius: 50%;
        }

        .actions {
            text-align: center;
        }

        .error-message {
            color: red;
            font-weight: bold;
            text-align: center;
        }

        button {
            background-color: #d9534f;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            display: block;
            margin: 20px auto 0;
        }

        button:hover {
            background-color: #c9302c;
        }

        a {
            display: block;
            text-align: center;
            margin-bottom: 20px;
            color: #007BFF;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Delete My Account</h1>
        <a href="../dashboard.php">Back to Dashboard</a>

        <?php if (isset($error)): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>

        <p class="warning">Warning: This action will delete all your data, including posts, and cannot be undone.</p>
        
        <ul>
            <li><strong>First Name:</strong> <?php echo htmlspecialchars($user['nombre']); ?></li>
            <li><strong>Last Name:</strong> <?php echo htmlspecialchars($user['apellidos']); ?></li>
            <li><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></li>
            <?php if ($user['avatar']): ?>
                <li class="avatar"><strong>Avatar:</strong><br>
                    <img src="../uploads/<?php echo htmlspecialchars(basename($user['avatar'])); ?>" alt="Avatar" width="100">
                </li>
            <?php endif; ?>
        </ul>

        <form action="eliminar_usuario.php" method="post">
            <div class="actions">
                <input type="checkbox" name="confirmar" id="confirmar">
                <label for="confirmar">I confirm that I want to delete my account</label><br>
                <button type="submit">Delete My Account</button>
            </div>
        </form>
    </div>
</body>
</html>
