<?php
session_start();
require 'db.php'; // Asegúrate de que este archivo está correctamente ubicado

// Verificar que el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Verificar que se recibió el ID de la publicación
if (!isset($_GET['id'])) {
    die("Error: ID de publicación no proporcionado.");
}

$post_id = $_GET['id'];

// Obtener los datos actuales de la publicación
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$post_id, $_SESSION['user_id']]);
$post = $stmt->fetch();

if (!$post) {
    die("Error: Publicación no encontrada o no tienes permiso para editarla.");
}

// Procesar la actualización de la publicación
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $content = $_POST['content'];
    $image = $post['image']; // Mantener la imagen existente si no se sube una nueva

    // Subir la nueva imagen si existe
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/project/uploads/';
        $tmp_name = $_FILES['image']['tmp_name'];
        $name = basename($_FILES['image']['name']);
        if (move_uploaded_file($tmp_name, $uploadDir . $name)) {
            $image = "uploads/$name"; // Actualizamos la ruta de la imagen
        } else {
            echo "Error al subir la imagen.";
        }
    }

    // Actualizar la publicación en la base de datos
    $stmt = $pdo->prepare("UPDATE posts SET content = ?, image = ? WHERE id = ? AND user_id = ?");
    $stmt->execute([$content, $image, $post_id, $_SESSION['user_id']]);

    header("Location: ../dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Publicación</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h1>Editar Publicación</h1>
    <a href="../dashboard.php">Volver al Dashboard</a>

    <form action="editar_publicacion.php?id=<?php echo htmlspecialchars($post_id); ?>" method="post" enctype="multipart/form-data">
        <label for="content">Comentario:</label><br>
        <textarea name="content" id="content" rows="4" required><?php echo htmlspecialchars($post['content']); ?></textarea><br>

        <!-- Mostrar la imagen actual -->
        <?php if ($post['image']): ?>
            <p>Imagen actual:</p>
            <img src="../<?php echo htmlspecialchars($post['image']); ?>" alt="Imagen de la Publicación" width="150"><br>
        <?php endif; ?>

        <label for="image">Actualizar Imagen (opcional):</label>
        <input type="file" name="image" id="image"><br>

        <button type="submit">Actualizar Publicación</button>
    </form>
</body>
</html>
