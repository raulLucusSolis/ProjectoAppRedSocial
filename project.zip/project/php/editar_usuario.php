<?php
session_start();
require 'db.php';

// Verificar que el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Obtener los datos del usuario logueado
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Procesar el formulario de actualización
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $email = $_POST['email'];
    $avatar = $user['avatar']; // Mantener el avatar existente si no se sube uno nuevo

    // Subir el nuevo avatar si existe
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/project/uploads/';
        $tmp_name = $_FILES['avatar']['tmp_name'];
        $name = basename($_FILES['avatar']['name']);
        $targetFile = $uploadDir . $name;

        if (move_uploaded_file($tmp_name, $targetFile)) {
            $avatar = "uploads/$name"; // Guardamos la ruta relativa en la base de datos
        } else {
            echo "Error al subir el avatar.";
        }
    }

    // Actualizar los datos del usuario en la base de datos
    $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ?, apellidos = ?, email = ?, avatar = ? WHERE id = ?");
    $stmt->execute([$nombre, $apellidos, $email, $avatar, $_SESSION['user_id']]);

    echo "¡Datos actualizados con éxito!";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h1>Edit Your Info</h1>

    <form action="editar_usuario.php" method="post" enctype="multipart/form-data">
        <!-- Mostrar el avatar actual si existe -->
        <?php if ($user['avatar']): ?>
            <p><strong>Current Avatar:</strong></p>
            <img src="../uploads/<?php echo htmlspecialchars(basename($user['avatar'])); ?>" alt="Current Avatar" width="100" style="border-radius: 50%;"><br><br>
        <?php endif; ?>

        <!-- Formulario para editar los datos del usuario -->
        <label for="nombre">First Name:</label>
        <input type="text" name="nombre" id="nombre" value="<?php echo htmlspecialchars($user['nombre']); ?>" required><br>

        <label for="apellidos">Last Name:</label>
        <input type="text" name="apellidos" id="apellidos" value="<?php echo htmlspecialchars($user['apellidos']); ?>" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required><br>

        <label for="avatar">New Avatar (optional):</label>
        <input type="file" name="avatar" id="avatar"><br>

        <button type="submit">Update</button>
    </form>

    <a href="../dashboard.php">Back to Dashboard</a>
</body>
</html>
