<?php
try {
    // Cambia localhost por la IP del servidor si no está en la misma máquina
    $dsn = "mysql:host=localhost;dbname=db_iaw_rrb;charset=utf8mb4"; // Conexión a MariaDB
    $username = "raulHernan"; // Usuario de MariaDB
    $password = "administrador"; // Contraseña de MariaDB

    // Crear la conexión con PDO
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>
