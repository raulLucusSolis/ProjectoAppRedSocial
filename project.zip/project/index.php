<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home Page</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
body {
    position: relative;
    background-image: url('css/index.png');
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
}

body::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(255, 255, 255, 0.9);
    z-index: -1;
}

    </style>

</head>
<body>
    <h1>Welcome to the Social Network</h1>
    <a href="login.php">Log In</a> | <a href="register.php">Register</a>
</body>
</html>
