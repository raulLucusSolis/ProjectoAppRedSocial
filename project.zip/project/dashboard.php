<?php
session_start();
require 'php/db.php';

// Verificar que el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Obtener los datos del usuario logueado
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Procesar el formulario de publicación
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $content = $_POST['content'];  // El comentario que el usuario escribe
    $image = null;

    // Subir la imagen si existe
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/project/uploads/';
        $tmp_name = $_FILES['image']['tmp_name'];
        $name = basename($_FILES['image']['name']);
        if (move_uploaded_file($tmp_name, $uploadDir . $name)) {
            $image = "uploads/$name";  // Guardamos la ruta de la imagen en la base de datos
        } else {
            echo "Error al subir la imagen.";
        }
    }

    // Insertar la publicación en la base de datos
    $stmt = $pdo->prepare("INSERT INTO posts (user_id, content, image) VALUES (?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $content, $image]);

    echo "¡Publicación exitosa!";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Centrar el avatar */
        .avatar-container {
            text-align: center;
        }

        .avatar-container img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
        }

        /* Centrar el logo */
        .center-logo {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        /* Centrar enlaces */
        .link-container {
            text-align: center;
        }

        .link-container a {
            display: inline-block;
            margin: 0 10px;
        }
    </style>
</head>
<body>
    <!-- Mostrar el logo centrado -->
    <img src="css/logo.png" alt="Logo" class="center-logo">

    <!-- Mostrar enlaces centrados -->
    <div class="link-container">
        <a href="php/logout.php">Log Out</a> | 
        <a href="php/editar_usuario.php">Edit My Info</a> | 
        <a href="php/eliminar_usuario.php">Delete My Account</a>
    </div>

    <!-- Mostrar el nombre del usuario -->
    <h1>Welcome, <?php echo htmlspecialchars($user['nombre']); ?>!</h1>

    <!-- Mostrar el avatar actual si existe y centrarlo -->
    <div class="avatar-container">
        <?php if ($user['avatar']): ?>
            <img src="uploads/<?php echo htmlspecialchars(basename($user['avatar'])); ?>" alt="Current Avatar">
        <?php endif; ?>
    </div>

    <h2>Create a New Post:</h2>
    <form action="dashboard.php" method="post" enctype="multipart/form-data">
        <textarea name="content" placeholder="Write your comment..." required></textarea><br>
        <input type="file" name="image"><br>
        <button type="submit">Post</button>
    </form>

    <h2>All Users' Posts:</h2>
    <?php
    // Consultar las publicaciones de todos los usuarios
    $stmt = $pdo->query("
        SELECT posts.*, usuarios.nombre, usuarios.apellidos 
        FROM posts 
        JOIN usuarios ON posts.user_id = usuarios.id 
        ORDER BY posts.created_at DESC
    ");
    $posts = $stmt->fetchAll();

    // Mostrar las publicaciones
    foreach ($posts as $post) {
        echo "<div>\n";
        echo "    <p><strong>" . htmlspecialchars($post['nombre']) . " " . htmlspecialchars($post['apellidos']) . ":</strong></p>\n";
        echo "    <p>" . htmlspecialchars($post['content']) . "</p>\n";
        if ($post['image']) {
            echo "    <img src='" . htmlspecialchars($post['image']) . "' alt='Image' width='100'><br>\n";
        }
        echo "    <small>Published on " . $post['created_at'] . "</small><br>\n";
        if ($post['user_id'] == $_SESSION['user_id']) {
            echo "    <a href='php/editar_publicacion.php?id=" . $post['id'] . "'>Edit</a> | \n";
            echo "    <a href='php/eliminar_publicacion.php?id=" . $post['id'] . "' onclick='return confirm(\"Are you sure you want to delete this post?\");'>Delete</a>\n";
        }
        echo "</div>\n";
        echo "<hr>\n";
    }
    ?>
</body>
</html>
