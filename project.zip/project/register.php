<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>User Registration</h1>
    <form action="php/register_handler.php" method="post" enctype="multipart/form-data">
        <label for="nombre">First Name:</label>
        <input type="text" name="nombre" id="nombre" required><br>

        <label for="apellidos">Last Name:</label>
        <input type="text" name="apellidos" id="apellidos" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>

        <label for="avatar">Avatar (optional):</label>
        <input type="file" name="avatar" id="avatar"><br>

        <button type="submit">Register</button>
    </form>
    <p><a href="index.php">Back to Home Page</a></p>
</body>
</html>
